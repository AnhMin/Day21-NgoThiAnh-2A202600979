# LoRA Adapter r=16

Adapter weights (`adapter_model.safetensors`) được tạo khi chạy notebook trên Google Colab.

## Export từ Colab

Sau khi training xong, adapter nằm tại:

```
/content/lab21_lora_t4/r16/
├── adapter_config.json
└── adapter_model.safetensors
```

Tải về và copy vào thư mục này trước khi nộp bài Option A.

Hoặc bật `MOUNT_DRIVE = True` trong notebook để lưu persistent trên Google Drive.
